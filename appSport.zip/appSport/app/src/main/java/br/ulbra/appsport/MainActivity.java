package br.ulbra.appsport;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtNP;
    RadioGroup rgOP;
    RadioButton rbC,rbM,rbL;
    CheckBox cbS,ckCM,ckCA;
    TextView txtRS;
    Button btnCalc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtNP = findViewById(R.id.edtNP);
        rgOP = findViewById(R.id.rgOP);
        rbC = findViewById(R.id.rbC);
        rbM = findViewById(R.id.rbM);
        rbL = findViewById(R.id.rbL);
        cbS = findViewById(R.id.cbS);
        txtRS = findViewById(R.id.txtRS);
        btnCalc = findViewById(R.id.btnCalc);
        ckCM = findViewById(R.id.ckCM);
        ckCA = findViewById(R.id.ckCA);
        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double p, resultado;
               try {


                   p = Double.parseDouble(edtNP.getText().toString());
                   int op = rgOP.getCheckedRadioButtonId();
                   if (op == R.id.rbC) {
                       resultado = (p * 0.5);
                   } else if (op == R.id.rbM) {
                       resultado = (p * 0.7);
                   } else {
                       resultado = (p * 1.2);
                   }
                   if (cbS.isChecked()) {
                       resultado = resultado + ((resultado * 10) / 100);
                   }else if (ckCM.isChecked()){
                       resultado = resultado + ((resultado *5)/100);
                   }if(ckCA.isChecked()){
                       resultado = resultado;
                   }
                   txtRS.setText("A distância percorrida é: " + resultado + "m");
               }catch (NumberFormatException e){
                   Toast.makeText(MainActivity.this, "Erro na digitação", Toast.LENGTH_SHORT).show();
               }

            }
        });
        };
    }
